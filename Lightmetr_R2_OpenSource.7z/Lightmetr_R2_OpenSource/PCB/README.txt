Sch & Pcb:
https://oshwhub.com/vegetableswim/lm_oled_copy

PCB Tickness 1.6mm